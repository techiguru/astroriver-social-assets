# Astro River: Seal C on the website (handover to Tech, 9 Oct 2026, SUN VERSION)

From the Social Media chat. The founder chose **Seal C** as the logo on 9 Oct 2026. This note replaces the crest note
(`TECH-NOTE.md` in *Crest kit - gold AR emblem (Oct 2026, not the logo)*, marked ON HOLD). Do nothing from that note.

> **CHANGED, 9 Oct evening. If you already built a branch from the first version of this note, redo the files.**
> The first Seal C had a four-point sparkle at the top. That is the shape AI products use (it reads as their logo),
> so the founder had it replaced by a sun. **Every file in `site/` has changed.** Copy all nine again over the ones on
> your branch and check them against the checksums at the end of this note. The code changes (sections 2, 3 and 5) are
> exactly the same as before: same file names, same sizes, same lines. Do not merge or push to `main` a branch that
> still has the sparkle files.

**Nothing in this note is approved for `main`.** The founder sees a preview branch first and decides. Sections 1–4
(icons) are one change; section 5 (header and footer) is a separate, visible change.

**Where the files are.** WorkDrive, team folder AR Assets, folder **Brand kit - Seal C (Oct 2026)**
(folder ID `ahdlo932578be555449b29cc02150911713d5`), subfolder `site/`. Every file there is already named as the site
wants it. Check each copy against the SHA-256 list at the end.

Checked against `origin/main` at `a64af86` (fetched 9 Oct). **Fetch `main` fresh and re-read `index.html`,
`public/manifest.json`, `vite.config.ts` and the anchor list in `scripts/prerender.mjs` before editing.**

## 1. Copy into `public/`

| From `site/` | To | What it is |
|---|---|---|
| `favicon.ico` | `public/favicon.ico` (replaces the old builder's heart icon) | Tab icon: 16, 32 and 48 px in one file |
| `favicon.png` | `public/favicon.png` (replaces) | The same icon, 32 px PNG |
| `favicon.svg` | `public/favicon.svg` (new) | The same icon as lines, sharp at any size |
| `apple-touch-icon.png` | `public/apple-touch-icon.png` (new) | iPhone home screen, 180 px, no see-through |
| `pwa-192x192.png` | `public/pwa-192x192.png` (new) | Named in the manifest already; was missing |
| `pwa-512x512.png` | `public/pwa-512x512.png` (new) | Named in the manifest already; was missing |
| `pwa-maskable-512x512.png` | `public/pwa-maskable-512x512.png` (new) | Android round/squircle crop; the seal sits in the safe zone |

Before committing, run RB-78's check on every PNG and ICO: `git hash-object --path public/<file> public/<file>` must equal
`git hash-object --no-filters public/<file>`. The SVGs are text and fall under `public/** text eol=lf`; they already have LF endings.

## 2. `index.html`: the icon lines only

Replace lines 37–38:
```html
<link rel="icon" type="image/png" href="/favicon.png" />
<link rel="apple-touch-icon" href="/favicon.ico" />
```
with:
```html
<link rel="icon" href="/favicon.ico" sizes="48x48" />
<link rel="icon" type="image/svg+xml" href="/favicon.svg" />
<link rel="icon" type="image/png" sizes="32x32" href="/favicon.png" />
<link rel="apple-touch-icon" href="/apple-touch-icon.png" />
```
and update the comment above them (lines 30–36): its TODO is done.

**Touch nothing else in the head.** `scripts/prerender.mjs` fails the build unless each of these appears exactly once, exactly
as now: `<html lang="en" class="dark">`, the `<title>`, `description`, `og:title`, `og:description`, `og:type`,
`theme-color` (`#0a0a0a`), `twitter:card` (`summary`), `</head>`, `<div id="root"></div>`. Do not add an `og:image`
(D-181: the build writes each page's own).

## 3. The icon list lives in two places

`public/manifest.json` **and** the `VitePWA({ manifest: { icons } })` block in `vite.config.ts` carry the same stale list
(a 16 px PNG, a "64 px" ICO, and pwa-512 reused as maskable). Change both to:
```json
"icons": [
  { "src": "/pwa-192x192.png", "sizes": "192x192", "type": "image/png" },
  { "src": "/pwa-512x512.png", "sizes": "512x512", "type": "image/png" },
  { "src": "/pwa-maskable-512x512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
]
```
In `vite.config.ts` also set `includeAssets` (line 28) to:
```ts
includeAssets: ["favicon.ico", "favicon.png", "favicon.svg", "apple-touch-icon.png", "pwa-192x192.png", "pwa-512x512.png", "pwa-maskable-512x512.png"],
```
and drop the TODO/NOTE comments above the icon list (lines 38–43). Keep `background_color` and `theme_color` (`#0A1428`).
After the build, open one page in `dist/` and count the manifest links: there should be one (`selfDestroying: true`, D-154).

## 4. Check after deploy

- `https://astroriver.com/favicon.ico` is no longer the heart. Fetch it fresh.
- A new tab shows a gold ring with a small gold **sun** at the top, on a night-purple disc. If you see a four-point sparkle, the old files are still in.
- iPhone: Share → Add to Home Screen shows the seal on a night tile.
- Chrome DevTools → Application → Manifest: three icons, no errors.
- Google shows the old icon until it next crawls the site. That is normal.

## 5. Separate change, founder's decision: the seal in the header and footer

Mockups: `preview/website-header-desktop.jpg`, `website-header-phone.jpg`, `website-footer.jpg`.

- Copy `site/astro-river-seal.svg` → `public/astro-river-seal.svg` (the small seal, on-light colours) and
  `site/astro-river-seal-footer.svg` → `public/astro-river-seal-footer.svg` (the full seal, on-dark colours).
- `src/components/landing/SiteHeader.tsx`, the desktop brand link (line 48):
```tsx
<Link to="/" className="flex shrink-0 items-center gap-3 whitespace-nowrap font-serif text-lg font-bold tracking-tight text-primary">
  <img src="/astro-river-seal.svg" alt="" width={34} height={40} className="h-10 w-auto" />
  Astro River Institute
</Link>
```
  The mobile menu's top bar (line 90) can take the same `<img>`. `alt=""` because the link already carries the name.
- `src/components/landing/InstitutionalFooter.tsx`, above the `<h4>` at line 54:
```tsx
<img src="/astro-river-seal-footer.svg" alt="" width={56} height={64} className="mb-3 h-16 w-auto" />
```
- The hero stays as it is (founder, 9 Oct).

## 6. Not part of this change

- Share pictures stay as D-181 draws them. `social/share-picture-1200x630.png` is for posts and outside use.
- Commit messages: no vendor or model names, no co-author trailers (D-156).

## Checksums (SHA-256) of the files this note uses (sun version)

| File | Bytes | SHA-256 |
|---|---|---|
| `site/apple-touch-icon.png` | 20,565 | `d28cd6cb5b9f903d6994f280e4cae2952973341571ec62abd2422b22bb32c18a` |
| `site/astro-river-seal-footer.svg` | 2,885 | `8f51c33f0c358bf9139f8d40d55620293077ca9fb06b0a38620573de91b1ce52` |
| `site/astro-river-seal.svg` | 2,380 | `f6061869f84f2e5201354cb34456df5aa2f659ce4679534d7388214bf909b3e5` |
| `site/favicon.ico` | 6,882 | `ea7436173374504bd854e898d346a2de1936dff9a7c2f957e6a933aedcc3a408` |
| `site/favicon.png` | 2,268 | `ea26a402d0705e0bd0cd9680df83a6c96d7c72d44daea17fea011de1e31a6c5e` |
| `site/favicon.svg` | 2,541 | `db3b07f424116ecccfe9ad1c7aac38296f4b09a62f707aae4b49ff0637c21079` |
| `site/pwa-192x192.png` | 22,468 | `2893bed3d3371a8c7ab213970c449b3263a39488883bef8862cdd793953e6555` |
| `site/pwa-512x512.png` | 102,189 | `38eb819beea4cd0de10c3f63eb6b522595beb002136d02755734ff0e4dae56f6` |
| `site/pwa-maskable-512x512.png` | 93,855 | `38d332cbc10871259eeaba1289f668c49290a7b79280e95ef042e79007623a44` |
