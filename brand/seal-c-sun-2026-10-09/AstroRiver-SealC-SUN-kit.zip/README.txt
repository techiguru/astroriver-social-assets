ASTRO RIVER: BRAND KIT, SEAL C (9 Oct 2026, sun version)
========================================================

Seal C is the logo: the Sun (Surya) sits in the opening at the top of the ring, and a river of
lights runs down from it and out through the bottom. The river comes from the sky and reaches the
earth (Akash Ganga, the river of the sky). Chosen by the founder on 9 Oct 2026.
The first draft had a four-point sparkle at the top; it was replaced by the sun the same day because
that sparkle is the shape AI products use. Do not use any file showing the sparkle.
It replaces the gold AR crest as the logo. The crest is kept in
AR Assets > Crest kit - gold AR emblem (Oct 2026, not the logo).
Home: WorkDrive > AR Assets > Brand kit - Seal C (Oct 2026).

START HERE
  AstroRiver-brand-sheet-SealC.pdf   three pages: every logo, the icons, the colours, how to use them
  TECH-NOTE.md                       for the site chat: which file goes where on the website

WHAT IS IN HERE

  logo/   every logo as SVG (lines: any size, stays sharp; give these to printers),
          plus PNG at 4096 px (print, big uses) and 1024 px (everyday). PNGs have see-through backgrounds.
    astro-river-logo-stacked-on-dark       THE MAIN LOGO: seal, ASTRO RIVER, INSTITUTE · EST. 2008, for night backgrounds
    astro-river-logo-stacked-on-light      the same for ivory and white
    astro-river-logo-stacked-one-colour-ink / -white    one colour: stamp, forms, embossing, embroidery
    astro-river-logo-horizontal-on-light / -on-dark     seal beside "Astro River Institute": header, letterhead, email signature
    astro-river-seal-on-dark / -on-light   the seal alone, where the name is already written
    astro-river-seal-small-on-dark / -on-light          bold version for anything under about 64 px
    astro-river-seal-one-colour-ink / -white / -gold     the seal in one colour (gold = foil)
    astro-river-logo-black-white.png       for the black-and-white office printer (on white)

  icons/  favicon.ico (16, 32 and 48 px in one file), favicon.svg, favicon-16/32/48.png,
          apple-touch-icon.png (iPhone), pwa-192x192.png, pwa-512x512.png, pwa-maskable-512x512.png (Android)
          The tab icon is its own drawing, centred on the ring.

  site/   exactly the files TECH-NOTE.md puts on the website, already named as the site wants them

  social/
    profile-picture-1080.png     Instagram, Facebook, WhatsApp, YouTube, LinkedIn, X (safe for the round crop)
    share-picture-1200x630.png   for posts and link previews outside the site
    x-banner-1500x500.jpg        X header, cut from the visiting card's river of stars

  card/   the river-of-stars visiting card (25 Sep), front and back, print PDFs with and without bleed

  preview/  the seal on the live website (header, phone, footer), the tab icon, two post styles

  old-astroriver-com-logo/   the 2019 astroriver.com logo with its original vector files, kept on record.
                             Not part of Seal C's look.

COLOURS
  Seal on dark:  ring and sun seal gold #D4AF5A (shaded #F2D99A to #B88A3A), river #F2D99A to #9A7BE0
  Seal on light: ring and sun deep seal gold #A97A24 (shaded #C79A3A to #86601A), river #B5832A to #6D28D9
  Night #0F092A, night glow #23185C
  Website (unchanged): ivory #FAF7F2, ink #1E1A14, deep purple #6D28D9, warm gold #D97706,
                       cosmic navy #0A1428, footer purple #1A0A2E

LETTERS
  Playfair Display for the name and headings, Inter for the rest. In the logo files the name is
  drawn as outlines, so no font is needed. The name is two words: Astro River.

GOOD TO KNOW
  - See-through PNGs look wrong in WhatsApp and some phone galleries. There, use the profile picture
    or the share picture.
  - Before printing anything, ask the printer for a proof. The visiting card PDFs hold pictures of the
    card (RGB): small text may come out soft and the purple can print duller than on screen.
